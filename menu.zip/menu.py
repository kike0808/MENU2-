class Arreglo:
    def __init__(self):
        self.arreglo = [[' ' for _ in range(4)] for _ in range(4)]

    def ingresar_arreglo(self):
        print("Ingrese el arreglo de 4x4:")
        for i in range(4):
            fila = input(f"Ingrese la fila {i + 1}: ")
            if len(fila) != 4:
                print("Por favor, ingrese 4 caracteres.")
                return
            self.arreglo[i] = list(fila)

    def imprimir_arreglo(self):
        print("El arreglo ingresado es:")
        for fila in self.arreglo:
            print(' '.join(fila))


class Pila:
    def __init__(self):
        self.items = []

    def insertar(self, elemento):
        self.items.append(elemento)

    def eliminar(self):
        if not self.items:
            print("La pila está vacía.")
            return None
        return self.items.pop()

    def imprimir(self):
        print("Elementos en la pila:")
        print(self.items)


class Cola:
    def __init__(self):
        self.items = []

    def insertar(self, elemento):
        self.items.append(elemento)

    def eliminar(self):
        if not self.items:
            print("La cola está vacía.")
            return None
        return self.items.pop(0)

    def imprimir(self):
        print("Elementos en la cola:")
        print(self.items)


def menu_principal():
    print("MENU PRINCIPAL")
    print("1. Arreglos")
    print("2. Pilas")
    print("3. Colas")
    print("4. Salida")


def submenu():
    print("SUBMENU")
    print("1. Insertar")
    print("2. Eliminar")
    print("3. Imprimir")
    print("4. Volver al menú principal")


def main():
    arreglo = Arreglo()
    pila = Pila()
    cola = Cola()

    while True:
        menu_principal()
        opcion = input("Ingrese su opción: ")

        if opcion == '1':
            arreglo.ingresar_arreglo()
        elif opcion == '2':
            while True:
                submenu()
                opcion_pila = input("Ingrese su opción: ")
                if opcion_pila == '1':
                    elemento = input("Ingrese el elemento a insertar en la pila: ")
                    pila.insertar(elemento)
                elif opcion_pila == '2':
                    pila.eliminar()
                elif opcion_pila == '3':
                    pila.imprimir()
                elif opcion_pila == '4':
                    break
                else:
                    print("Opción inválida.")
        elif opcion == '3':
            while True:
                submenu()
                opcion_cola = input("Ingrese su opción: ")
                if opcion_cola == '1':
                    elemento = input("Ingrese el elemento a insertar en la cola: ")
                    cola.insertar(elemento)
                elif opcion_cola == '2':
                    cola.eliminar()
                elif opcion_cola == '3':
                    cola.imprimir()
                elif opcion_cola == '4':
                    break
                else:
                    print("Opción inválida.")
        elif opcion == '4':
            print("Saliendo del programa...")
            break
        else:
            print("Opción inválida.")


if __name__ == "__main__":
    main()
